﻿namespace Flyweight
{
}
