﻿namespace Singleton
{
  
}
