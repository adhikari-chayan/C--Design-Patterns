﻿namespace Iterator
{
}
