﻿namespace Composite
{
}
