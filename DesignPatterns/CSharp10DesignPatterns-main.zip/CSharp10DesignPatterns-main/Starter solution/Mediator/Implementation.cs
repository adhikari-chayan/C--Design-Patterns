﻿namespace Mediator
{
}
 