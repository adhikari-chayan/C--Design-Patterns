﻿namespace Observer
{
}
