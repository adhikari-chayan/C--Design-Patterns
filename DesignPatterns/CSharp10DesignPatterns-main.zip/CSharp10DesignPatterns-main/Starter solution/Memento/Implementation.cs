﻿namespace Memento
{
}