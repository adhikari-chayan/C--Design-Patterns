﻿namespace Decorator
{
}
