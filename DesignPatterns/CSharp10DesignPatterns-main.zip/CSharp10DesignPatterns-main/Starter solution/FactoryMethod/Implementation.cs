﻿namespace FactoryMethod
{
   
}
