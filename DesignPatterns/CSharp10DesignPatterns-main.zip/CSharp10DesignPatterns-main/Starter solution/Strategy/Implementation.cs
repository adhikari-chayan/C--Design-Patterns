﻿namespace Strategy
{
}
