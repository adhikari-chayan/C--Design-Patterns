﻿namespace ChainOfResponsibility
{
}