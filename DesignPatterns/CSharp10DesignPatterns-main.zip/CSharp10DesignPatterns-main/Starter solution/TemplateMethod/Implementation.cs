﻿namespace TemplateMethod
{ 
}
